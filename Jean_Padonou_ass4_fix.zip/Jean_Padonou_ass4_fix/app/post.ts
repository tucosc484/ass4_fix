export class Post {
  id: number;
  name: string;
}
