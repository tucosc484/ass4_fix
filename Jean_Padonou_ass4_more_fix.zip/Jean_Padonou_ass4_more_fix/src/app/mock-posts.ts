import { Post } from './post';

export const POSTS: Post[] = [
  { id: 1, name: 'Post 1' },
  { id: 2, name: 'Post 2' },
  { id: 3, name: 'Post 3' },
  { id: 4, name: 'Post 4' },
  { id: 5, name: 'Post 5' },
  { id: 6, name: 'Post 6' },
  { id: 7, name: 'Post 7' },
  { id: 8, name: 'Post 8' },
  { id: 9, name: 'Magma 9' },
  { id: 10, name: 'Post 10' }
];
